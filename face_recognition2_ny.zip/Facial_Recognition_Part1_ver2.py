#여기서 돌리는거
#https://yongku.tistory.com/entry/%EC%98%81%EC%83%81%EC%B2%98%EB%A6%ACPython-OpenCV%EB%A5%BC-%EC%9D%B4%EC%9A%A9%ED%95%9C-%EC%96%BC%EA%B5%B4-%EC%9D%B8%EC%8B%9DFace-Detection-%EC%9E%A0%EA%B8%88-%ED%95%B4%EC%A0%9C-%EB%B0%8F-Web-Browser-%EC%8B%A4%ED%96%89-%EC%98%88%EC%A0%9C
import cv2
import numpy as np


import face_recog
#face detetcion xml파일
face_classifier = cv2.CascadeClassifier('haarcascade_frontalface_default.xml')
body_cascade = cv2.CascadeClassifier('./haarcascade_fullbody.xml')

##전체 사진에서 얼굴 부위만 잘라 리턴
def face_extractor(img):

#사진 흑백처리
    gray = cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)

#얼굴 찾기
    faces = face_classifier.detectMultiScale(gray,1.3,5)
#찾은 얼굴이 없으면 non return
    if faces is():
        return None
#찾은얼굴이 있으면 얼굴 크기만큼 cropped_face 에저장
 #근데... 얼굴이 2개 이상 감지되면??
        #가장 마지막의 얼굴만 남을 듯
    for(x,y,w,h) in faces:
        cropped_face = img[y:y+h, x:x+w]
    return cropped_face

#노트북 webcam활성화
cap = cv2.VideoCapture(0)
#저장할 이미지 카운트 변수
count = 16

while True:
    #웹캠으로 사진 1장 읽어오기
    ret, frame = cap.read()
    #좌우반전
    frame = cv2.flip(frame, 1)
    # 얼굴 이미지 크기를 200x200으로 조정
    if face_extractor(frame) is not None:
        count+=1
        face = cv2.resize(face_extractor(frame),(200,200))
        # 조정된 이미지를 흑백으로 변환
        face = cv2.cvtColor(face, cv2.COLOR_BGR2GRAY)
        #파일 이름은 user숫자. jpg로 저장
        # knowns폴더에 jpg파일로 저장
        file_name_path = 'knowns/user'+str(count)+'.jpg'
        cv2.imwrite(file_name_path,face)
        # 화면에 얼굴과 현재 저장 개수 표시
        cv2.putText(face,str(count),(50,50),cv2.FONT_HERSHEY_COMPLEX,1,(0,255,0),2)
        cv2.imshow('Face Cropper',face)
    else:
        print("Face not Found")
        pass

    if cv2.waitKey(1)==13 or count==15:
        break

cap.release()
cv2.destroyAllWindows()
print('Colleting Samples Complete!!!')
